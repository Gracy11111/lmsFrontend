package com.example.learningmanagementsystem.Enum;

public enum UserRole {
    STUDENT,TEACHER,ADMIN
}
