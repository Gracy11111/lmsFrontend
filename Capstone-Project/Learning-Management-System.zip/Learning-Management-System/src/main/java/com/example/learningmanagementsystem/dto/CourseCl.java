package com.example.learningmanagementsystem.dto;


import jakarta.persistence.Table;

@Table(name = "courseCl")
public class CourseCl {


    String CourseName;

    int teacherId;



}
