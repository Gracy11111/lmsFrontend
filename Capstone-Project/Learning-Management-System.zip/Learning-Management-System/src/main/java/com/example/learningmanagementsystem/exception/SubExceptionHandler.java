package com.example.learningmanagementsystem.exception;

public class SubExceptionHandler extends Exception{

    public SubExceptionHandler(){
        super();
    }
}
