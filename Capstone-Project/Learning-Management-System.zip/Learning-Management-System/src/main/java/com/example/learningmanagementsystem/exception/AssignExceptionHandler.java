package com.example.learningmanagementsystem.exception;

public class AssignExceptionHandler extends Exception{

    public AssignExceptionHandler(){
        super();
    }
}
