package com.example.learningmanagementsystem.exception;

public class CourseExceptionHandler extends Exception {

    public CourseExceptionHandler(){
        super();
    }


}
