package com.example.learningmanagementsystem.exception;

public class ClassExceptionHandler extends Exception{

    public ClassExceptionHandler(){
        super();
    }
}
