package com.example.learningmanagementsystem.service;

import com.example.learningmanagementsystem.Enum.UserRole;
import com.example.learningmanagementsystem.exception.ClassExceptionHandler;
import com.example.learningmanagementsystem.model.Classes;
import com.example.learningmanagementsystem.model.User;
import com.example.learningmanagementsystem.repository.IRepositoryUser;
import com.example.learningmanagementsystem.repository.IclassesRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClassesServiceImpl implements IClassesService{

    @Autowired
    IclassesRepo iclassesRepo;

    @Autowired
    IRepositoryUser repositoryUser;
    @Override
    public List<Classes> getAllClass() {
        List<Classes> classes=iclassesRepo.findAll();
        return classes;
    }
    @Override
    public Classes save(Classes classes) throws ClassExceptionHandler {
//        Classes c=iclassesRepo.save(classes);
//        return c;
        User user=repositoryUser.findById(classes.getUser().getId()).orElse(null);
        if (user.getRole().equals(UserRole.TEACHER)) {
            classes.getUser().setId(user.getId());
            classes.getUser().setUserName(user.getUserName());
            classes.getUser().setPassword(user.getPassword());
            classes.getUser().setRole(user.getRole());
            Classes c = iclassesRepo.save(classes);
            return c;
        }else {

            throw new ClassExceptionHandler();
        }
    }

    @Override
    public void deleteById(int classId) {
        iclassesRepo.deleteById(classId);
    }


}
